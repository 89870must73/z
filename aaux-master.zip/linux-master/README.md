<p align="left">
<b>apt update && apt-get -y install git && git clone https://github.com/rayvynlee/linux && cd linux && chmod +x openvpn.sh && ./openvpn.sh</b>
<br>
<br> 
<br>  
<br> 
Powered by: PisoVPN<br>
Feel free to fork
<br>
https://www.pisovpn.com
